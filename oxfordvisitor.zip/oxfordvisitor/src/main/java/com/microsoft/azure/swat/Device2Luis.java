package com.microsoft.azure.swat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/*
 * Usage: java -cp oxfordvisitor-0.0.1-SNAPSHOT.jar com.microsoft.azure.swat.Device2Luis
 */
public class Device2Luis {

	public static void main(String[] args) {
		HttpClient httpclient = HttpClients.createDefault();

        try
        {
        	InputStreamReader isr = new InputStreamReader(httpclient.getClass().getResourceAsStream("/requestBody.json"), "UTF-8"); 
            Properties prop = new Properties();
			prop.load(isr); 
			 
			while (true) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
				System.out.print("Enter your search words: ");
				String searchWords = reader.readLine();
				if(searchWords.equalsIgnoreCase("exit")) break;

				// The URL pattern is
				// https://api.projectoxford.ai/luis/v1.0/prog/apps/{appId}/search?searchKeywords={searchKeywords}&maxQueriesCount={maxQueriesCount}
			    //String url = "https://api.projectoxford.ai/luis/v1.0/prog/apps"
				//           + "/"+prop.getProperty("appId")
				//           + "/search?searchKeywords="+searchWords
				//           + "&maxQueriesCount="+prop.getProperty("maxQueriesCount");
				//URIBuilder builder = new URIBuilder(url);

				//URI uri = builder.build();
				//HttpGet request = new HttpGet(uri);
				//request.setHeader("Ocp-Apim-Subscription-Key", prop.getProperty("Ocp-Apim-Subscription-Key"));
			   
				
				
				String en_Searchwords = Encode(searchWords,"UTF-8");
				
				String uri = "https://api.projectoxford.ai/luis/v1/application?id=" +prop.getProperty("appId")
						+ "&subscription-key=" + prop.getProperty("Ocp-Apim-Subscription-Key")
						+ "&q=" + en_Searchwords;
				
				
				HttpGet request = new HttpGet(uri);
				
				HttpResponse response = httpclient.execute(request);
				HttpEntity entity = response.getEntity();
				String es = "[" +EntityUtils.toString(entity) +"]";
				JSONArray joes = new JSONArray(es);
				double score = 0;
				String intent = null;
				JSONArray joe =null;
				for(int i=0; i<joes.length(); i++){
					JSONObject jo = joes.getJSONObject(i);
					JSONArray joi = jo.getJSONArray("intents");
					joe = jo.getJSONArray("entities");
					for(int j=0; j<joi.length(); j++){
						JSONObject joj = joi.getJSONObject(j);
						if(joj.getDouble("score")>score){
							score = joj.getDouble("score");
							intent = joj.getString("intent");
						}
					}
				}
				if (entity != null) {
					System.out.println("Server response: intent - "+intent + "; Score: " +score);
					for(int i=0; i<joe.length();i++){
					System.out.println("Entity - "+ joe.getJSONObject(i).getString("entity") + " Type:" + joe.getJSONObject(i).getString("type"));
					}
				System.out.println("LUIS Response Jason Data Is :");
				System.out.println(es);
				}
			}
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
	}
	
	 public static String Encode(String text, String Endocing) { 
	        StringBuffer result = new StringBuffer(); 
	        for (int i = 0; i < text.length(); i++) { 
	            char c = text.charAt(i); 
	            if (c >= 0 && c <= 255) { 
	                result.append(c); 
	            } 
	            else { 
	                byte[] b = new byte[0]; 
	                try { 
	                    b = Character.toString(c).getBytes(Endocing); 
	                } 
	                catch (Exception e) { 
	                    e.printStackTrace(); 
	                } 
	                for (int j = 0; j < b.length; j++) { 
	                    int k = b[j]; 
	                    if (k < 0) 
	                        k += 256; 
	                    result.append("%" + Integer.toHexString(k).toUpperCase()); 
	                } 
	            } 
	        } 
	        return result.toString(); 
	    } 


}

/*
 				HttpResponse response = httpclient.execute(request);
				HttpEntity entity = response.getEntity();
				String es = EntityUtils.toString(entity);
				JSONObject jor = null;
				JSONArray joes = new JSONArray(es);
				double score = 0;
				String intent = null;
				for(int i=0; i<joes.length(); i++){
					JSONObject jo = joes.getJSONObject(i);
					JSONArray joi = jo.getJSONArray("IntentsResults");
					for(int j=0; j<joi.length(); j++){
						JSONObject joj = joi.getJSONObject(j);
						if(joj.getDouble("score")>score){
							jor = jo;
							score = joj.getDouble("score");
							intent = joj.getString("Name");
						}
					}
				}
				if (entity != null) {
					System.out.println("Server response: intent - "+intent + "; Entity - "+jor.getJSONArray("EntitiesResults").getJSONObject(0).getString("word"));
					System.out.println(es);
				}
 */
 